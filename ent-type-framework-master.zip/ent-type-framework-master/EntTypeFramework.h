#ifndef __ENT_TYPE_FRAMEWORK_H__
#define __ENT_TYPE_FRAMEWORK_H__
 
#ifdef __cplusplus
extern "C" {
#endif

/* 通用 */
#include "EtF_Config.h" 
#include "type.h"
#include "list.h"
#include "Fifo.h"
#include "common.h"
#include "object.h"

/* 框架 */
#if ETF_DEVICE_EN                       //设备框架
#include "Device.h"
#endif

#if ETF_COROUTINE_EN                    //协程框架
#include "Coroutine.h"
#endif

#if ETF_EVENT_EN                        //事件框架
#include "Event.h"
#endif

#if ETF_TIMER_EN                        //定时器框架
#include "Timer.h"
#endif

/* 组件 */
#if USE_CONSOLE_UART
#include "console.h"
#endif

#if USE_SLOG
#include "slog.h"
#endif

#if USE_ETF_I2C
#include "etf_i2c.h"
#endif

#if USE_LP
#include "low_power.h"
#endif

#ifdef __cplusplus
}
#endif
 
#endif
 

