#ifndef __EVENT_H__
#define __EVENT_H__
 
#ifdef __cplusplus
extern "C" {
#endif
 
#include "type.h"


/* 单独启用事件，未启用协程时的事件结构关联的执行结构定义 */
#if ((!ETF_COROUTINE_EN)&&(ETF_EVENT_EN))
#define etf_event_fun_t                     etf_uint8_t (*coroutine)(etf_event_ev_t ev, etf_event_data_t data)
#elif (ETF_COROUTINE_EN&&ETF_EVENT_EN)
#define etf_event_fun_t                     struct etf_co_tcb *
#endif


/* 事件类型 */
typedef etf_uint8_t                         etf_event_ev_t;
typedef void *                              etf_event_data_t;

/* 事件控制块 */
struct etf_event{

    /* 对象继承，必须为第一个成员 */
    struct etf_object                       parent;
    /* 事件值 */
    etf_event_ev_t                          ev;
    /* 事件数据 */
    etf_event_data_t                        data;
    /* 关联的过程 */
    etf_event_fun_t                         p;
};

typedef struct etf_event *                  etf_event_t;

void etf_event_synch(etf_event_fun_t p, etf_event_ev_t ev, etf_event_data_t data);
etf_err_t etf_event_post(etf_event_fun_t p, etf_event_ev_t ev, etf_event_data_t data);
etf_event_ev_t etf_event_alloc(void);
void etf_event_module_init(void);
etf_uint32_t etf_event_run(void);

#ifdef __cplusplus
}
#endif
 
#endif
 

