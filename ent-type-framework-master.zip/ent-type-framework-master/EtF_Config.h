#ifndef __ETF_CONFIG_H__
#define __ETF_CONFIG_H__
 
#include "arm_compat.h"

#ifdef __cplusplus
extern "C" {
#endif
 
#define ETF_OBJ_NAME_MAX                    15              //对象名最大长度
#define ETF_IN_ASSERT_DEBUG                 1               //使能ETF内部断言调试接口

#define ETF_DEVICE_EN                       1               //使能设备框架
#define ETF_COROUTINE_EN                    1               //使能协程框架
#define ETF_EVENT_EN                        1               //使能事件框架
#define ETF_TIMER_EN                        1               //使能定时器框架

#define ETF_CO_AUTOSTART_ENABLE             1               //使能协程自启动数组


#if ETF_EVENT_EN
#define ETF_EVENT_NUM_MAX                   20              //最大事件数量
#endif

#if ((0x80 <= ETF_EVENT_NUM_MAX)||(1 > ETF_EVENT_NUM_MAX))
#error "(0x80 <= ETF_EVENT_NUM_MAX)||(1 > ETF_EVENT_NUM_MAX)"
#endif


#if (ETF_COROUTINE_EN&&ETF_TIMER_EN)
/* 定时器系统心跳 */
#define ETF_TIMER_CLOCK_SEC                 500


#define USE_CONSOLE_UART                    1               //串口控制台
#define USE_SLOG                            1               //使能slog
#define	USE_ETF_I2C							1               //使能I2C框架
#define USE_LP                              0               //使能低功耗组件

#if USE_SLOG
#define USE_SLOG_COLOR                      1               //使能slog带颜色输出
#define CONFIG_SLOG_TAG_SIZE                8               //标签名最大长度
#endif

#endif

/* 协程自动初始化 */
#if (ETF_COROUTINE_EN&&ETF_CO_AUTOSTART_ENABLE)
#define ETF_CO_AUTOSTART_PROCESSES(...)										\
etf_err_t (* const autostart_processes[])(void) = {__VA_ARGS__, ETF_NULL}
#endif

#if USE_CONSOLE_UART
/* 指令最大参数数量 */
#define CONFIG_CONSOLE_CMD_PARA_SIZE                      6
/* 指令与参数最大数据长度 */
#define CONFIG_CONSOLE_CMD_SIZE                           15
/* 最大历史指令数量 */
#define CONFIG_CONSOLE_CMD_HISTORY_NUM                    4
/* 串口波特率 */
#define CONFIG_CONSOLE_CMD_BAUD                           115200
/* 控制台使用串口设备名 */
#define	CONFIG_CONSOLE_DEVICE_NAME						  "debug"
#endif

/* 中断处理 */
#define ETF_IRQ_DISABLE()                   __disable_irq();
#define ETF_IRQ_ENABLE()                    __enable_irq();
/* 软重启 */
void HAL_NVIC_SystemReset(void);
#define ETF_REBOOT()                        HAL_NVIC_SystemReset()

#ifdef __cplusplus
}
#endif
 
#endif
 

