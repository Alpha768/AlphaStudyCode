# 1 ETF配置

在"EntTypeFramework/Etf_Config.h"文件中通过更改宏定义来配置框架程序。

<pre>
#define ETF_OBJ_NAME_MAX                    20              //对象名最大长度
#define ETF_IN_ASSERT_DEBUG                 1               //使能ETF内部断言调试接口

#define ETF_DEVICE_EN                       1               //使能设备框架
#define ETF_COROUTINE_EN                    1               //使能协程框架
#define ETF_EVENT_EN                        1               //使能事件框架
#define ETF_TIMER_EN                        1               //使能定时器框架

#define ETF_CO_AUTOSTART_ENABLE             1               //使能协程自启动数组

/* 需要使能事件框架程序 */
#if ETF_EVENT_EN
#define ETF_EVENT_NUM_MAX                   32              //最大事件数量
#endif

/* 可定义用户事件数量检查 */
#if ((0x80 <= ETF_EVENT_NUM_MAX)||(1 > ETF_EVENT_NUM_MAX))
#error "(0x80 <= ETF_EVENT_NUM_MAX)||(1 > ETF_EVENT_NUM_MAX)"
#endif


#if (ETF_COROUTINE_EN&&ETF_TIMER_EN)
/* 定时器系统心跳 */
#define ETF_TIMER_CLOCK_SEC                 1000			//每秒进入中断次数

/* 需关联控制台 */
#define USE_CONSOLE_UART                    1               //串口控制台
#define USE_SLOG                            1               //使能slog

#if USE_SLOG
#define USE_SLOG_COLOR                      1               //使能slog带颜色输出
#define CONFIG_SLOG_TAG_SIZE                8               //标签名最大长度
#endif

#endif

/* 协程自动初始化，数组宏定义 */
#if (ETF_COROUTINE_EN&&ETF_CO_AUTOSTART_ENABLE)
#define ETF_CO_AUTOSTART_PROCESSES(...)										\
etf_err_t (* const autostart_processes[])(void) = {__VA_ARGS__, ETF_NULL}
#endif

#if USE_CONSOLE_UART
/* 指令最大参数数量 */
#define CONFIG_CONSOLE_CMD_PARA_SIZE                      8
/* 指令与参数最大数据长度 */
#define CONFIG_CONSOLE_CMD_SIZE                           15
/* 最大历史指令数量 */
#define CONFIG_CONSOLE_CMD_HISTORY_NUM                    5
/* 串口波特率 */
#define CONFIG_CONSOLE_CMD_BAUD                           115200
/* 控制台使用串口设备名 */
#define	CONFIG_CONSOLE_DEVICE_NAME						  "debug"
#endif

/* 中断处理 */
#define ETF_IRQ_DISABLE()                   __disable_irq();
#define ETF_IRQ_ENABLE()                    __enable_irq();
/* 软重启 */
#define ETF_REBOOT()                        NVIC_SystemReset()
</pre>

---
# 2 文件包含
在需要使用框架程序的文件中包含"EntTypeFramework/EntTypeFramework.h"。

---
# 3 协程任务框架使用
协程使用样例程序：
<pre>

/* 自动初始化数组，所有需要自动初始化的函数放到此数组中，类型为 etf_err_t xxx(void)。一般将此数组定义在main.c中*/
#if ETF_CO_AUTOSTART_ENABLE && ETF_COROUTINE_EN
ETF_CO_AUTOSTART_PROCESSES(debug_bsp_init, console_ps_init, led_init, leds_app_init);
#endif

/**
 *  leds处理协程
 *
 *@param :
 *
 *@return:
 *
 *@note  : 
 *
 *
 */
ETF_PROCESS(leds_ps, co_ev, co_data){

	/* 每次进入协程都会执行ETF_PROCESS(leds_ps, co_ev, co_data) 到 ETF_PROCESS_BEGIN()之间的代码，不需要保存的
       临时变量可以定义到这里 */

	/* 协程处理开始 */
    ETF_PROCESS_BEGIN();

	/* 从 ETF_PROCESS_BEGIN() 到 事件等待 处，只会在任务启动后执行一次，需要初始化执行的代码可以放到这里，需要保存的
       变量定义为static类型 */

    static struct etf_timer					leds_timer;
    static etf_device_t                     leds_dev            = ETF_NULL;

    leds_dev                                                    = etf_device_find("leds");

    ETF_IN_ASSERT(ETF_NULL != leds_dev);
    
    ETF_IN_ASSERT(ETF_EOK == etf_device_open(leds_dev, ETF_DEVICE_FLAG_WRONLY));
    
    while(1){

		/* 延时等待，实际为[事件等待]的封装，满足条件后处理后面代码 */
        etf_delayms((&leds_timer), 200);

		/* 协程任务处理代码，处理完成后会继续等待上面的事件 */
        etf_device_control(leds_dev, LEDS_CTRL_CMD_TURN, (void *)LED_ALL);
    }

	/* 协程处理结束 */
    ETF_PROCESS_END();
}

/* 定义协程任务控制对象 */
struct etf_co_tcb                           leds_ps;

/**
 *  leds协程初始化
 *
 *@param :
 *
 *@return:
 *
 *@note  : 
 * 如果开机自动初始化可以放在自动初始化数组中
 *
 */
etf_err_t leds_app_init(void){

	/* 初始化协程对象 */
    etf_coroutine_init(&leds_ps, "leds_ps", ETF_PROCESS_NAME_GET(leds_ps));
	/* 启动协程 */
    etf_coroutine_startup(&leds_ps);

    return ETF_EOK;
}
</pre>

如样例程序
<pre>ETF_PROCESS(leds_ps, co_ev, co_data)</pre>
为定义的协程处理任务。参数leds\_ps为任务函数名(通过宏定义ETF_PROCESS与leds\_ps拼接出函数名)，co\_ev为传递到任务的事件值，co\_data为跟随事件的数据类型为(void *)。协程任务的参数个数固定，除了leds\_ps为自定义协程任务函数名外，其它名字固定为co\_ev和co_data不可更改；

<pre>struct etf_co_tcb                           leds_ps;</pre>
为定义的协程对象，说有协程的操作都是对对象的操作；  

## 3.1协程任务实现流程
![协程任务操作流程](../Figures/协程任务操作流程.png)

## 3.2协程框架API
|函数|void etf_coroutine_module_init(void)|
|---|------------------------------------|
|功能|初始化协程框架模块，在框架程序运行前调用|
|参数|无|
|返回|无|

|函数|struct etf_co_tcb * etf_coroutine_init(struct etf_co_tcb * const co_tcb, const char *name, etf_uint8_t (*coroutine)(struct pt * co_pt, coroutine_event_t co_ev, coroutine_data_t co_data));|
|---|------------------------------------|
|功能|初始化协程对象，协程任务在启动之前需要先初始化对象|
|参数*co_tcb|协程对象指针|
|参数name|协程任务名|
|参数*coroutine|协程处理任务函数名，通过ETF_PROCESS_NAME_GET(name)宏定义获取，宏定义参数name是定义协程处理任务时的第一个参数,任务函数名|
|返回|协程任务对象地址；ETF_NULL初始化失败|

|函数|etf_err_t etf_coroutine_unregister(struct etf_co_tcb * const co_tcb)|
|---|------------------------------------|
|功能|删除已初始化的协程任务对象|
|参数co_tcb|需要删除的协程任务对象|
|返回|ETF_EOK:成功；其它错误|

|函数|etf_err_t etf_coroutine_startup(struct etf_co_tcb * const co_tcb)|
|---|------------------------------------|
|功能|启动协程任务|
|参数co_tcb|需要启动的协程任务对象|
|返回|ETF_EOK:成功；其它错误|

|函数|etf_err_t etf_coroutine_suspend(struct etf_co_tcb * const co_tcb)|
|---|------------------------------------|
|功能|挂起已启动的协程任务|
|参数co_tcb|需要挂起的协程任务对象|
|返回|ETF_EOK:成功；其它错误|

|函数|etf_err_t etf_coroutine_resume(struct etf_co_tcb * const co_tcb)|
|---|------------------------------------|
|功能|恢复已挂起的协程任务|
|参数co_tcb|需要挂起的协程任务对象|
|返回|ETF_EOK:成功；其它错误|

|函数|void etf_poll_requested(struct etf_co_tcb * const co_tcb, coroutine_data_t co_data)|
|---|------------------------------------|
|功能|请求轮询一次指定的协程任务|
|参数co_tcb|需要轮询任务对象|
|参数co_data|传递的数据|
|返回|无|


|函数|etf_uint32_t etf_coroutine_run(void)|
|---|------------------------------------|
|功能|协程任务轮询请求处理函数，需要一直轮询调用|
|参数|无|
|返回|0<有未处理请求|

---
# 4 事件驱动框架使用
事件驱动框架程序在使用前需要先调用etf_event_module_init()函数初始化框架模块，之后循环调用etf_event_run()函数来处理事件。

## 4.1 事件驱动框架API
|函数|void etf_event_module_init(void)|
|---|------------------------------------|
|功能|事件框架初始化函数，在框架程序运行前调用|
|参数|无|
|返回|无|

|函数|etf_event_ev_t etf_event_alloc(void)|
|---|------------------------------------|
|功能|事件值分配函数，范围0<值<0x80。设计初衷使用在资源较小的MUC系统中，所以事件值类型没有设的很大。|
|参数|无|
|返回|分配得到的事件值|

|函数|void etf_event_synch(etf_event_fun_t p, etf_event_ev_t ev, etf_event_data_t data)|
|---|------------------------------------|
|功能|投递事件，同步模式，调用这个接口函数会在内部直接执行需要处理事件的协程任务。|
|参数p|需要投递事件所到的协程任务对象|
|参数ev|事件值|
|参数data|传递的数据|
|返回|无|

|函数|etf_err_t etf_event_post(etf_event_fun_t p, etf_event_ev_t ev, etf_event_data_t data)|
|---|------------------------------------|
|功能|投递事件，异步模式，会在事件轮询函数中处理事件|
|参数p|需要投递事件所到的协程任务对象|
|参数ev|事件值|
|参数data|传递的数据|
|返回|无|

|函数|etf_uint32_t etf_event_run(void)|
|---|------------------------------------|
|功能|事件轮询函数，需要一直轮询调用|
|参数|无|
|返回|0<有未处理事件|

# 5 软件定时器框架使用
软定时器框架程序在使用前需要先调用etf_timer_module_init()函数初始化框架模块。之后循环调用etf_timer_run()函数来处理软定时器调度。
|函数|void etf_timer_module_init(void)|
|---|------------------------------------|
|功能|软定时器框架初始化函数，在框架程序运行前调用|
|参数|无|
|返回|无|

|函数|void etf_timer_clock(void)|
|---|------------------------------------|
|功能|软定时器框架心跳时钟处理函数，插入到用于心跳定时器的中断函数中执行|
|参数|无|
|返回|无|

|函数|clock_time_t etf_timer_get_clock(void)|
|---|------------------------------------|
|功能|获取当前心跳时钟tick计数|
|参数|无|
|返回|当前心跳时钟计数|

|函数|etf_err_t etf_ctimer_set(char *name, etf_timer_t timer, clock_time_t tim, etf_timer_type_e type, etf_ctimer_fun_t callback)|
|---|------------------------------------|
|功能|设置定时器，回调方式为执行函数|
|参数name|定时器名，只在第一对定时器调用这个函数时有效|
|参数timer|需要设置的定时器对象|
|参数tim|定时器定时时间，心跳tick数，如需要时间单位，需要把时间转换为心跳数传入|
|参数type|软件定时器类型，一次性定时器(超时停止)或周期定时器（循环定时）|
|参数callback|回调函数,定时器到期执行此回调函数|
|返回|ETF_EOK：设置成功；其它失败|

|函数|etf_err_t etf_etimer_set(char *name, etf_timer_t timer, clock_time_t tim, etf_timer_type_e type, etf_ctimer_fun_t callback)|
|---|------------------------------------|
|功能|设置定时器，回调方式为执行协程任务|
|参数name|定时器名，只在第一对定时器调用这个函数时有效|
|参数timer|需要设置的定时器对象|
|参数tim|定时器定时时间，心跳tick数，如需要时间单位，需要把时间转换为心跳数传入|
|参数type|软件定时器类型，一次性定时器(超时停止)或周期定时器（循环定时）|
|参数callback|回调函数,定时器到期执行此协程任务|
|返回|ETF_EOK：设置成功；其它失败|

|函数|etf_err_t etf_timer_start(etf_timer_t timer)|
|---|------------------------------------|
|功能|定时器启动|
|参数timer|需要启动的定时器对象|
|返回|ETF_EOK：设置成功；其它失败|

|函数|etf_err_t etf_timer_stop(etf_timer_t timer)|
|---|------------------------------------|
|功能|定时器停止|
|参数timer|需要停止的定时器对象|
|返回|ETF_EOK：设置成功；其它失败|

|函数|etf_err_t etf_timer_restart(etf_timer_t timer)|
|---|------------------------------------|
|功能|定时器重启|
|参数timer|需要重启的定时器对象|
|返回|ETF_EOK：设置成功；其它失败|

|函数|void etf_timer_run(void)|
|---|------------------------------------|
|功能|定时器轮询函数，需要一直轮询调用|
|参数|无|
|返回|无|

# 6 设备框架使用
通过设备框架程序定义组织设备例程：
<pre>
/* 自动初始化数组，所有需要自动初始化的函数放到此数组中，类型为 etf_err_t xxx(void)。一般将此数组定义在main.c中*/
#if ETF_CO_AUTOSTART_ENABLE && ETF_COROUTINE_EN
ETF_CO_AUTOSTART_PROCESSES(debug_bsp_init, console_ps_init, led_init, leds_app_init);
#endif

/* init、open、close、read、write、control为设备具体执行接口函数 */

/* 设备初始化。再打开设备的时候自动执行。参数：设备句柄、打开标志 */
etf_err_t leds_init(etf_device_t dev){

    GPIO_InitTypeDef                        GPIO_InitType;
    
    __HAL_RCC_GPIOC_CLK_ENABLE();

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
    
    GPIO_InitType.Pin                       = GPIO_PIN_13;
    GPIO_InitType.Speed                     = GPIO_SPEED_LOW;
    GPIO_InitType.Mode                      = GPIO_MODE_OUTPUT_PP;

    HAL_GPIO_Init(GPIOC, &GPIO_InitType);
    
    return ETF_EOK;
}

/* 打开设备。参数：设备句柄、打开标志 */
etf_err_t leds_open(etf_device_t dev, etf_flag_t flag){
    return ETF_EOK;
}

/* 关闭设备。参数：设备句柄 */
etf_err_t leds_close(etf_device_t dev){
    return ETF_EOK;
}

/* 读设备。参数：设备句柄、读设备寄存器地址、数据存放地址、数据尺寸 */
etf_size_t leds_read(etf_device_t dev, etf_off_t pos, void *buffer, etf_size_t size){
    return 0;
}

/* 写设备。参数：设备句柄、写设备寄存器地址、数据存放地址、数据尺寸 */
etf_size_t leds_write(etf_device_t dev, etf_off_t pos, const void *buffer, etf_size_t size){
    return 0;
}

/* 控制设备。参数：设备句柄、控制指令、参数 */
etf_err_t leds_control(etf_device_t dev, etf_uint32_t cmd, void *args){

//    GPIO_TypeDef  *                     GPIOx;
//    uint16_t                            GPIO_Pin;
    
//    led_num_e                           led_num             = (led_num_e)args;

    switch(cmd){
    case    LEDS_CTRL_CMD_BRIGHT        :
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
    break;

    case    LEDS_CTRL_CMD_DARK          :
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
    break;

    case    LEDS_CTRL_CMD_TURN          :
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
    break;
    }
    return ETF_EOK;
}

/* 定义设备对象 */
static struct etf_device            led_device;
/* 定义接口用结构体类型实例，并关联接口函数 */
static struct etf_device_ops ops                            = {

    .init                                                   = leds_init,
    .open                                                   = leds_open,
    .close                                                  = leds_close,
    .read                                                   = leds_read,
    .write                                                  = leds_write,
    .control                                                = leds_control
};

/**
 *  LED设备注册
 *
 *@param :
 *
 *@return:
 *
 *@note  : 
 *
 *
 */
etf_err_t led_init(void){

    etf_err_t                       res                     = ETF_EOK;
	/* 关联设备操作接口 */
    led_device.ops                                          = &ops;
	/* 设备类型设置 */
    led_device.type                                         = ETF_Device_Class_Miscellaneous;
	/* 注册设备 */
    res                                                     = etf_device_register(&led_device, "leds", ETF_DEVICE_FLAG_WRONLY);
    
    return res;
}
</pre>

设备只有在注册后才可以被使用。设备框架程序在使用前需要先调用etf_device_module_init()函数初始化框架模块  

|函数|void etf_device_module_init(void)|
|---|------------------------------------|
|功能|设备框架初始化函数，在框架程序运行前调用|
|参数|无|
|返回|无|

|函数|etf_err_t etf_device_register(etf_device_t dev, const char *name, etf_uint16_t flags)|
|---|------------------------------------|
|功能|设备注册函数|
|参数dev|需要注册的设备对象|
|参数name|设备名|
|参数flags|设备标志属性，如只读、只写、读写等|
|返回|ETF_EOK：成功；其它错误|

|函数|etf_err_t etf_device_unregister(etf_device_t dev)|
|---|------------------------------------|
|功能|解除设备注册函数|
|参数dev|需要解除注册的设备对象|
|返回|ETF_EOK：成功；其它错误|

|函数|etf_device_t etf_device_find(const char *name)|
|---|------------------------------------|
|功能|通过设备名查找设备对象地址|
|参数name|设备名|
|返回|设备对象地址；ETF_NULL：未找到；|

|函数|etf_err_t rt_device_init(etf_device_t dev)|
|---|------------------------------------|
|功能|初始化设备|
|参数dev|需要初始化的设备对象|
|返回|ETF_EOK：成功；其它错误|

|函数|etf_err_t etf_device_open(etf_device_t dev, etf_uint16_t oflag)|
|---|------------------------------------|
|功能|打开设备|
|参数dev|需要打开的设备对象|
|参数oflag|打开方式的标志，如读写、中断|
|返回|ETF_EOK：成功；其它错误|

|函数|etf_err_t etf_device_close(etf_device_t dev)|
|---|------------------------------------|
|功能|关闭设备|
|参数dev|需要关闭的设备对象|
|返回|ETF_EOK：成功；其它错误|

|函数|etf_size_t etf_device_read(etf_device_t dev, etf_off_t pos, void *buffer, etf_size_t size)|
|---|------------------------------------|
|功能|设备读|
|参数dev|设备对象|
|参数pos|读起始位置|
|参数buffer|读到数据的缓存地址|
|参数size|读数据尺寸|
|返回|实际读到的数据尺寸|

|函数|etf_size_t etf_device_write(etf_device_t dev, etf_off_t pos, const void *buffer, etf_size_t size)|
|---|------------------------------------|
|功能|设备写|
|参数dev|设备对象|
|参数pos|写起始位置|
|参数buffer|需要写入数据存放的缓冲地址|
|参数size|写数据尺寸|
|返回|实际写入的数据尺寸|

|函数|etf_err_t etf_device_control(etf_device_t dev, etf_uint32_t cmd, void *arg)|
|---|------------------------------------|
|功能|设备控制操作|
|参数dev|设备对象|
|参数cmd|控制指令|
|参数arg|指令参数|
|返回|ETF_EOK：成功；其它错误|

|函数|etf_err_t etf_device_set_rx_indicate(etf_device_t dev, etf_err_t (*rx_ind)(etf_device_t dev, etf_size_t size))|
|---|------------------------------------|
|功能|设置设备中断回调函数|
|参数dev|设备对象|
|参数rx_ind|中断回调函数|
|返回|ETF_EOK：成功；其它错误|

# 7 控制台组件使用
控制台组件需要使用串口进行交互，所以使用前需先通过设备框架程序实现串口驱动程序。在运行控制台程序之前需先调用console_ps_init()函数初始化控制台组件。  

控制台使用例程：
<pre>
/* 指令添加列表。一般将此数组定义在main.c中*/
#if USE_CONSOLE_UART
/* 指令添加列表 */
CON_CMD_TABLE(&ConCmdReboot, &ConCmdVersion, &ConCmdHelp, &ConCmdCoroutine, &ConCmdDevice, &ConCmdEvent, &ConCmdTimer, &ConCmdSlogList, &ConCmdSlogFilter, &ConCmdSlogTest);
#endif

etf_int32_t ConCmd_Reboot(etf_int32_t argc, con_cmd_analysis *argv);

/* CPU重启指令 */
con_cmd                         ConCmdReboot                = {
    .Cmd                                                    = "reboot", //指令
    .DesStr                                                 = "The software restarts the CPU.\r\n", //描述信息
    .Fun                                                    = ConCmd_Reboot //指令执行函数
};

/*
 * 重启指令执行函数
 * 
 * @param  ：argc：输入的参数数量
 *           argv：输入的参数数组
 *
 * @return ：0：成功；其它失败；
 *
 * @note   ：
 * 
 */
etf_int32_t ConCmd_Reboot(etf_int32_t argc, con_cmd_analysis *argv){

    ETF_REBOOT();
    return 0;
}
</pre>

自带基础指令：

- reboot：系统软重启；
- version：打印版本信息；
- help：打印指令列表；
- device_list：打印设备信息，列表方式；
- event_list：打印事件信息，列表方式；
- timer_list：打印软定时器信息，列表方式；
- ps：打印协程信息；
- [Tab按键]：指令补全；
- [上/下箭头按键]：历史指令翻看；

# 8 log控制台打印组件使用
log控制台打印组件基于控制台实现，需要先实现控制台功能。在运行log程序之前需先调用SlogInit()函数初始化log组件。  

log通过结构体组织。打印log信息时可通过标签来对log信息进行区分。  
每个标签有5种打印状态：  

- SLOG_E_VALID：只可以打印错误类型信息；
- SLOG_I_VALID：只可以打印提示类型信息；
- SLOG_D_VALID：只可以打印调试类型信息；
- SLOG_T_VALID：可以打印全部类型信息(错误类型、提示类型、调试类型)；
- SLOG_F_VALID：不可以打印任何信息；

log结构体类型：
<pre>
typedef struct slog_ctrl{
  char                      Tag[CONFIG_SLOG_TAG_SIZE+1];  //标签
  etf_uint8_t               Valid;  //类型有效标志
  etf_uint8_t               ANoValid; //无效标志，用于临时关闭所有打印信息的标志
  struct slog_ctrl  *       Next; //log结构链表
}slog_ctrl;
</pre>

log控制台打印组件例程：
<pre>

#ifdef  USE_SLOG
/* SLOG自动初始化数组链表，定义的log结构体对象需要加入这个数组初始化后才可以使用，一般将此数组定义在main.c中 */
SLOG_AUTO_INIT(slog_test);
#endif

/* 定义log对象 */
slog_ctrl                       SlogTest;

/* 初始化log对象 */
void slog_test(void){
  /* 配置log对象SlogTest，标签为"slog_tst", 标签默认状态为SLOG_T_VALID，可打印全部信息类型 */
  slog_config(&SlogTest, "slog_tst", SLOG_T_VALID);
}
/* 打印测试 */
int ConCmd_slog_Test(int argc, con_cmd_analysis *argv){
  /* 打印错误类型信息 */
  SLOG_E(SlogTest, "%s", "test sloh error.");
  /* 打印提示类型信息 */
  SLOG_I(SlogTest, "%s", "test sloh info.");
  /* 打印调试类型信息 */
  SLOG_D(SlogTest, "%s", "test sloh debug.");
  return 0;
}

</pre>

通过控制台可以修改和查看log标签输出状态  
设置标签状态命令格式  

- slog_filter tag f [关闭全部标签打印]   
- slog_filter tag r [恢复关闭前标签打印状态]  
- slog_filter 需要设置的标签 t [可打印所有类型信息]  
- slog_filter 需要设置的标签 f [不可打印任何信息]  
- slog_filter 需要设置的标签 e [仅打印错误类型信息]  
- slog_filter 需要设置的标签 i [仅打印提示类型信息]   
- slog_filter 需要设置的标签 d [仅打印调试类型信息]  