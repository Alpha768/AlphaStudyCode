# 1 文件组织结构

![文件组织结构](../Figures/文件组织结构.png)

- common目录  
该目录包含一些基础工具程序。例如：链表操作、FIFO队列操作、对象操作、字符串操作、基础数据类型等。

- Event  
该目录包含事件处理程序。例如：事件投递、事件轮询、事件等待、事件值分配等。

- Coroutine  
该目录包含协程处理程序。例如：协程创建、协程挂起、协程轮询等；

- Timer  
该目录包含软件定时器处理程序。例如：心跳时钟处理、软定时器设置、软定时器启动等；

- Device  
该目录包含设备框架程序。例如：设备注册、设备打开、关闭、读写等；

- Component  
该目录包含组件程序。现支持控制台、log控制台打印；

- Doc
该目录包含说明文档；

- "EntTypeFramework.h"  
文件定义了框架程序所有需要包含头文件；

- "Etf_Config.h"  
为配置文件，框架程序通过此文件中的宏定义来配置；

---
# 2 程序架构

![程序架构](../Figures/程序框架.png)

移植层：框架程序运行的基础，根据不同的处理器需要用户自己完成。基本运行只需要移植中断管理和心跳定时器即可。使用控制台与LOG组件功能需要在设备管理框架下，实现串口通讯驱动；  

框架构建层：核心部分，是程序运行调度、协程事件通讯的基础。设备管理框架程序也在这部分中实现；  

组件与应用层：组件主要用于系统调试。应用代码基于框架层实现，通过框架来规范应用程序的编写与逻辑处理过程，实现程序架构管理；

---
# 3 框架程序组织管理方式
框架程序大量使用结构体来构建对象的概念，并通过链表方式管理；  
## 3.1 对象类型继承
框架程序中通过结构体构建了一个基础对象类型（struct etf_object），其他对象类型都需要在结构体第一个成员中包含此基础对象类型，如下图所示：  
![对象继承](../Figures/对象继承.png)


## 3.2 对象管理
目前框架程序包含的对象类型有协程对象类型、事件对象类型、软定时器类型、设备对象类型。所有对象都通过对象容器来组织管理，对象容器会给每类对象分配两个链表，一个为运行链表，一个为挂起链表。所有对象根据运行情况都会被连接到这两个链表中的一个上，如图所示：  
![对象容器](../Figures/对象容器.png)

对象基类型
<pre>
//对象基类型
struct etf_object{
    char                            name[ETF_OBJ_NAME_MAX]; //对象名
    etf_uint8_t                     type;                   //对象类型
    etf_uint8_t                     flag;                   //对象标志
    enum etf_object_list_state_type state;                  //对象链接在对象容器对应类型的哪个链表中
    etf_list_t                      list;                   //对象列表节点
};
</pre>
对象容器节点类型
<pre>
/**
 * 对象容器节点类型
 */
struct etf_object_information{
    enum etf_object_class_type      type;               /**< object class type */
    etf_list_t                      object_run_list;    /**< object run list */
    etf_list_t                      object_suspend_list;/**< object suspend list */
    etf_size_t                      object_size;        /**< object size */
};
</pre>
目前所支持的对象类型
<pre>
enum etf_object_class_type{
    ETF_Object_Class_Null   = 0,                        /**< 对象未被使用. */
    
#if ETF_DEVICE_EN
    ETF_Object_Class_Device,                            /**< 对象类型是设备. */
#endif

#if ETF_COROUTINE_EN
    ETF_Object_Class_Coroutine,                         /**< 对象类型是协程. */
#endif

#if ETF_EVENT_EN
    ETF_Object_Class_Event,                             /**< 对象类型是事件. */
#endif

#if ETF_TIMER_EN
    ETF_Object_Class_Timer,                             /**< 对象类型是定时器. */
#endif

    ETF_Object_Class_Static = 0x80                      /**< 对象静态属性，初始化后设置 */
};
</pre>
所有的对象的管理实际上都是对链表进行操作，插入，删除等。应用程序中一般不需要直接来管理这些对象。在编写应用程序的时候调用相应的框架程序接口函数，框架就会自动实现对象的管理操作。详细的细节可以查看源代码。