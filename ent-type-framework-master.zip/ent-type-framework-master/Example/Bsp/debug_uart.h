#ifndef __DEBUG_UART_H__
#define __DEBUG_UART_H__
 
#ifdef __cplusplus
extern "C" {
#endif

/* 设备缓冲区尺寸 */
#define CONFIG_DEBUG_TX_BUFFER_SIZE             64
#define CONFIG_DEBUG_RX_BUFFER_SIZE             64

/* 控制指令 */
#define DEBUG_CTRL_CMD_BAUDRATE                 0x00000001          //波特率设置


etf_err_t debug_bsp_init(void);

#ifdef __cplusplus
}
#endif
 
#endif
 

