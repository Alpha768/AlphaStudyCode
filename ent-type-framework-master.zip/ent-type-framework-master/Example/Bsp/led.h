#ifndef __LED_H__
#define __LED_H__
 
#ifdef __cplusplus
extern "C" {
#endif
 
#define LEDS_CTRL_CMD_BRIGHT                    0x00000001          //LEDÁÁ
#define LEDS_CTRL_CMD_DARK                      0x00000002          //LEDÃð
#define LEDS_CTRL_CMD_TURN                      0x00000003          //LED×´Ì¬·­×ª

typedef enum{LED_ALL, LED_1, LED_2, LED_3} led_num_e;

etf_err_t led_init(void);

#ifdef __cplusplus
}
#endif
 
#endif
 

