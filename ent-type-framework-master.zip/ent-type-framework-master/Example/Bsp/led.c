/**
 * Copyright (c) 2006-2020, zwl
 * 
 * description  LED设备驱动
 * 
 * Change Logs:
 * Date             Author         Notes
 * 2021-01-26       Zwl             创建
 * 
 */
#include "main.h"
#include "EntTypeFramework.h"
#include "led.h"


/* 设备初始化。再打开设备的时候自动执行。参数：设备句柄、打开标志 */
etf_err_t leds_init(etf_device_t dev){

    GPIO_InitTypeDef                        GPIO_InitType;
    
    __HAL_RCC_GPIOC_CLK_ENABLE();

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
    
    GPIO_InitType.Pin                       = GPIO_PIN_13;
    GPIO_InitType.Speed                     = GPIO_SPEED_LOW;
    GPIO_InitType.Mode                      = GPIO_MODE_OUTPUT_PP;

    HAL_GPIO_Init(GPIOC, &GPIO_InitType);
    
    return ETF_EOK;
}

/* 打开设备。参数：设备句柄、打开标志 */
etf_err_t leds_open(etf_device_t dev, etf_flag_t flag){
    return ETF_EOK;
}

/* 关闭设备。参数：设备句柄 */
etf_err_t leds_close(etf_device_t dev){
    return ETF_EOK;
}

/* 读设备。参数：设备句柄、读设备寄存器地址、数据存放地址、数据尺寸 */
etf_size_t leds_read(etf_device_t dev, etf_off_t pos, void *buffer, etf_size_t size){
    return 0;
}

/* 写设备。参数：设备句柄、写设备寄存器地址、数据存放地址、数据尺寸 */
etf_size_t leds_write(etf_device_t dev, etf_off_t pos, const void *buffer, etf_size_t size){
    return 0;
}

/* 控制设备。参数：设备句柄、控制指令、参数 */
etf_err_t leds_control(etf_device_t dev, etf_uint32_t cmd, void *args){

//    GPIO_TypeDef  *                     GPIOx;
//    uint16_t                            GPIO_Pin;
    
//    led_num_e                           led_num             = (led_num_e)args;

    switch(cmd){
    case    LEDS_CTRL_CMD_BRIGHT        :
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
    break;

    case    LEDS_CTRL_CMD_DARK          :
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
    break;

    case    LEDS_CTRL_CMD_TURN          :
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
    break;
    }
    return ETF_EOK;
}

static struct etf_device            led_device;

static struct etf_device_ops ops                            = {

    .init                                                   = leds_init,
    .open                                                   = leds_open,
    .close                                                  = leds_close,
    .read                                                   = leds_read,
    .write                                                  = leds_write,
    .control                                                = leds_control
};

/**
 *  LED设备注册
 *
 *@param :
 *
 *@return:
 *
 *@note  : 
 *
 *
 */
etf_err_t led_init(void){

    etf_err_t                       res                     = ETF_EOK;

    led_device.ops                                          = &ops;
    led_device.type                                         = ETF_Device_Class_Miscellaneous;

    res                                                     = etf_device_register(&led_device, "leds", ETF_DEVICE_FLAG_WRONLY);
    
    return res;
}










