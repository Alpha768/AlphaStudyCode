/**
 * Copyright (c) 2006-2020, zwl
 * 
 * description  LED服务
 * 
 * Change Logs:
 * Date             Author         Notes
 * 
 * 
 */
#include "EntTypeFramework.h"
#include "Bsp.h"

/**
 *  leds处理协程
 *
 *@param :
 *
 *@return:
 *
 *@note  : 
 *
 *
 */
ETF_PROCESS(leds_ps, co_ev, co_data){

    ETF_PROCESS_BEGIN();

    static struct etf_timer					leds_timer;
    static etf_device_t                     leds_dev            = ETF_NULL;

    leds_dev                                                    = etf_device_find("leds");

    ETF_IN_ASSERT(ETF_NULL != leds_dev);
    
    ETF_IN_ASSERT(ETF_EOK == etf_device_open(leds_dev, ETF_DEVICE_FLAG_WRONLY));
    
    while(1){
        etf_delayms((&leds_timer), 200);
        etf_device_control(leds_dev, LEDS_CTRL_CMD_TURN, (void *)LED_ALL);
    }

    ETF_PROCESS_END();
}

/**
 *  leds协程初始化
 *
 *@param :
 *
 *@return:
 *
 *@note  : 
 *
 *
 */
struct etf_co_tcb                           leds_ps;

etf_err_t leds_app_init(void){
    etf_coroutine_init(&leds_ps, "leds_ps", ETF_PROCESS_NAME_GET(leds_ps));
    etf_coroutine_startup(&leds_ps);

    return ETF_EOK;
}







