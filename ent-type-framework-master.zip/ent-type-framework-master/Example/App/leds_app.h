#ifndef __LEDS_APP_H__
#define __LEDS_APP_H__

#include "type.h"

#ifdef __cplusplus
extern "C" {
#endif
 
etf_err_t leds_app_init(void);
 
#ifdef __cplusplus
}
#endif
 
#endif
 

