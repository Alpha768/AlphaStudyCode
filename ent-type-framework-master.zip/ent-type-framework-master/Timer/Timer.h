#ifndef __TIMER_H__
#define __TIMER_H__

#include "type.h"

#ifdef __cplusplus
extern "C" {
#endif


#if ETF_COROUTINE_EN
#define etf_delayms(timer, name, ms)                                                                                  \
    do{                                                                                                         \
        clock_time_t                        tick;                                                               \
        if(0 < ms){                                                                                             \
            tick                                    = ETF_TIMER_CLOCK_SEC * (ms / 1000);                        \
            tick                                   += (ETF_TIMER_CLOCK_SEC * (ms % 1000) +999 ) /1000;          \
            if(ETF_EOK == etf_etimer_set(name, timer, tick, TIMER_TYPE_ONE, etf_process_current)){           	\
                etf_timer_start(timer);                                                                         \
                ETF_PROCESS_WAIT_EVENT_UNTIL(ETF_PROCESS_EVENT_TIMER == co_ev);                                 \
            }                                                                                                   \
        }                                                                                                       \
    }while(0)
#endif

#define clock_time_t_max                    0xFFFFFFFF

/* ms 转换为tick */
#define	etf_from_ms_to_tick(ms)						(ms/(1000/ETF_TIMER_CLOCK_SEC))
/* tick 转换为ms */
#define	etf_from_tick_to_ms(tick)					(tick*(1000/ETF_TIMER_CLOCK_SEC))
/* 单独启用事件，未启用协程时的事件结构关联的执行结构定义 */
typedef void(*etf_ctimer_fun_t)(void);

#if ETF_COROUTINE_EN
typedef struct etf_co_tcb *					etf_etimer_fun_t;
#endif

/*一次定时器，周期定时器*/
typedef enum {TIMER_TYPE_ONE, TIMER_TYPE_PERIOD} etf_timer_type_e;

typedef etf_uint32_t                        clock_time_t;

/* 定时器控制块 */
struct etf_timer{

    /* 对象继承，必须为第一个成员 */
    struct etf_object                       parent;
    /* 定时器开始值 */
    clock_time_t                            start_v;
    /* 定时器间隔时值 */
    clock_time_t                            interval_v;
    /* 定时器类型 */
    etf_timer_type_e                        type;
    /* 关联的回调函数 */
    etf_ctimer_fun_t                        c_callback;
    /* 关联的协程 */
#if ETF_COROUTINE_EN
    etf_etimer_fun_t                        e_callback;
#endif

};

typedef struct etf_timer *                  etf_timer_t;

void etf_timer_clock(void);
clock_time_t etf_timer_get_clock(void);
void etf_timer_set_clock(clock_time_t m_tick);
clock_time_t etf_timer_get_next_expiration(void);
etf_err_t etf_ctimer_set(char *name, etf_timer_t timer, clock_time_t tim, etf_timer_type_e type, etf_ctimer_fun_t callback);
#if ETF_COROUTINE_EN
etf_err_t etf_etimer_set(char *name, etf_timer_t timer, clock_time_t tim, etf_timer_type_e type, etf_etimer_fun_t callback);
#endif
etf_err_t etf_timer_start(etf_timer_t timer);
etf_err_t etf_timer_stop(etf_timer_t timer);
etf_err_t etf_timer_restart(etf_timer_t timer);
void etf_timer_run(void);
void etf_timer_module_init(void);

#ifdef __cplusplus
}
#endif
 
#endif
 

