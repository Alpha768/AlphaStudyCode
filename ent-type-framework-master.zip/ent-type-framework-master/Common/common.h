#ifndef __COMMON_H__
#define __COMMON_H__

#include "Etf_Config.h"

#ifdef __cplusplus
extern "C" {
#endif

#define	etf_printf(fmt, args...)

#if ETF_IN_ASSERT_DEBUG
    #define ETF_IN_ASSERT(EX)                                                           \
        do{                                                                             \
            if (!(EX)){                                                                 \
                etf_printf("¡¾*¡¿(%s) assertion failed at function:%s, line number:%d \n", #EX, __FUNCTION__, __LINE__);	\
                while(1);                                                               \
            }                                                                           \
        }while(0)
#else
    #define ETF_IN_ASSERT(EX)
#endif


char *etf_strncpy(char *dst, const char *src, etf_uint32_t n);
etf_int32_t etf_strncmp(const char *cs, const char *ct, etf_uint32_t count);
etf_uint32_t etf_strlen(const char *s);
char* etf_itoa(etf_int32_t num, char* str, etf_int32_t radix);

void etf_module_init(void);
etf_uint32_t etf_run(void);
void etf_co_autostart_start(etf_err_t (* const processes[])(void));
etf_uint32_t etf_strlench(char *cmdstr, char ch);
etf_uint16_t etf_strstrlen(char *src, char *obj);

#ifdef __cplusplus
}
#endif
 
#endif
 

