#ifndef __TYPE_H__
#define __TYPE_H__

#include "Etf_Config.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 内联函数关键字定义 */
#define etf_inline              static __inline

/* 空字符 */
#define ETF_NULL                            (0)

/* boolean类型定义 */
#define ETF_TRUE                            1               /**< 真  */
#define ETF_FALSE                           0               /**< 假 */

#define	ETF_RESET							0
#define	ETF_SET								1
/* 错误码定义 */
#define ETF_EOK                             0               /**< 无错误 */
#define ETF_ERROR                           1               /**< 通用错误代码 */
#define ETF_ETIMEOUT                        2               /**< 超时 */
#define ETF_EFULL                           3               /**< 资源满 */
#define ETF_EEMPTY                          4               /**< 资源空 */
#define ETF_ENOMEM                          5               /**< 无内存 */
#define ETF_ENOSYS                          6               /**< 无系统 */
#define ETF_EBUSY                           7               /**< 忙 */
#define ETF_EIO                             8               /**< IO错误 */
#define ETF_EINTR                           9               /**< 中断系统调用 */
#define ETF_EINVAL                          10              /**< 无效参数 */

/* 内部保留事件 */
#define ETF_PROCESS_EVENT_NONE              0x80
#define ETF_PROCESS_EVENT_INIT              0x81
#define ETF_PROCESS_EVENT_POLL              0x82
#define ETF_PROCESS_EVENT_EXIT              0x83
#define ETF_PROCESS_EVENT_SERVICE_REMOVED   0x84
#define ETF_PROCESS_EVENT_CONTINUE          0x85
#define ETF_PROCESS_EVENT_MSG               0x86
#define ETF_PROCESS_EVENT_EXITED            0x87
#define ETF_PROCESS_EVENT_TIMER             0x88
#define ETF_PROCESS_EVENT_COM               0x89
#define ETF_PROCESS_EVENT_MAX               0x8a


/* 基础类型名称定义 */
typedef unsigned int            etf_uint32_t;
typedef int                     etf_int32_t;
typedef unsigned short          etf_uint16_t;
typedef short                   etf_int16_t;
typedef unsigned char           etf_uint8_t;
typedef char                    etf_int8_t;
typedef int                     etf_bool_t;
typedef int                     etf_err_t;

typedef etf_uint32_t            etf_flag_t;
typedef etf_uint32_t            etf_off_t;
typedef etf_uint32_t            etf_size_t;

/**
 * 对象类型
 * - 对象未被使用
 * - 对象类型为设备
 */
enum etf_object_class_type{
    ETF_Object_Class_Null   = 0,                        /**< 对象未被使用. */
    
#if ETF_DEVICE_EN
    ETF_Object_Class_Device,                            /**< 对象类型是设备. */
#endif

#if ETF_COROUTINE_EN
    ETF_Object_Class_Coroutine,                         /**< 对象类型是协程. */
#endif

#if ETF_EVENT_EN
    ETF_Object_Class_Event,                             /**< 对象类型是事件. */
#endif

#if ETF_TIMER_EN
    ETF_Object_Class_Timer,                             /**< 对象类型是定时器. */
#endif

    ETF_Object_Class_Static = 0x80                      /**< 对象静态属性，初始化后设置 */
};

/* 对象所在链表状态 */
enum etf_object_list_state_type{
    ETF_Object_list_state_null              = 0,        /**< 对象未插入到链表中 */
    ETF_Object_list_state_run_list,                     /**< 对象链接在运行链表中 */
    ETF_Object_list_state_suspend_list                  /**< 对象链接在挂起链表中 */
};

/* 链表节点类型 */
struct etf_list_node{
    struct etf_list_node *next;                                 /**< 指向前一个节点. */
    struct etf_list_node *prev;                                 /**< 指向后一个节点. */
};
typedef struct etf_list_node                etf_list_t;         /**< 定义链表节点类型. */

//对象基类型
struct etf_object{
    char                            name[ETF_OBJ_NAME_MAX]; //对象名
    etf_uint8_t                     type;                   //对象类型
    etf_uint8_t                     flag;                   //对象标志
    enum etf_object_list_state_type state;                  //对象链接在对象容器对应类型的哪个链表中
    etf_list_t                      list;                   //对象列表节点
};
typedef struct etf_object *                 etf_object_t;
/**
 * 对象容器节点类型
 */
struct etf_object_information{
    enum etf_object_class_type      type;               /**< object class type */
    etf_list_t                      object_run_list;    /**< object run list */
    etf_list_t                      object_suspend_list;/**< object suspend list */
    etf_size_t                      object_size;        /**< object size */
};

#ifdef __cplusplus
}
#endif
 
#endif
 

