/*
 * ²¿·Ö²Î¿¼RT-Thread
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
*/
#ifndef __OBJECT_H__
#define __OBJECT_H__
 
#include "type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ETF_LIST_INSERT_AFTER_RUN_LIST(information, object)                                                 \
    do{                                                                                                     \
        ETF_IRQ_DISABLE();                                                                                  \
        object->state                                           = ETF_Object_list_state_run_list;           \
        object->type                                            = object->type | ETF_Object_Class_Static;   \
        etf_list_insert_after(&(information->object_run_list), &(object->list));                            \
        ETF_IRQ_ENABLE();                                                                                   \
    }while(0)

#define ETF_LIST_INSERT_AFTER_SUSPEND_LIST(information, object)                                             \
    do{                                                                                                     \
        ETF_IRQ_DISABLE();                                                                                  \
        object->state                                           = ETF_Object_list_state_suspend_list;       \
        object->type                                            = object->type | ETF_Object_Class_Static;   \
        etf_list_insert_after(&(information->object_suspend_list), &(object->list));                        \
        ETF_IRQ_ENABLE();                                                                                   \
    }while(0)


#define ETF_LIST_INSERT_BEFORE_RUN_LIST(information, object)                                                \
    do{                                                                                                     \
        ETF_IRQ_DISABLE();                                                                                  \
        object->state                                           = ETF_Object_list_state_run_list;           \
        object->type                                            = object->type | ETF_Object_Class_Static;   \
        etf_list_insert_before(&(information->object_run_list), &(object->list));                           \
        ETF_IRQ_ENABLE();                                                                                   \
    }while(0)
    
#define ETF_LIST_INSERT_BEFORE_SUSPEND_LIST(information, object)                                            \
    do{                                                                                                     \
        ETF_IRQ_DISABLE();                                                                                  \
        object->state                                           = ETF_Object_list_state_suspend_list;       \
        object->type                                            = object->type | ETF_Object_Class_Static;   \
        etf_list_insert_before(&(information->object_suspend_list), &(object->list));                       \
        ETF_IRQ_ENABLE();                                                                                   \
    }while(0)

void etf_object_init(struct etf_object *object, enum etf_object_class_type type, const char *name);
void etf_object_detach(etf_object_t object);
etf_uint8_t etf_object_get_type(etf_object_t object);
enum etf_object_list_state_type etf_object_get_state(etf_object_t object);
etf_bool_t etf_object_is_systemobject(etf_object_t object);
struct etf_object_information * etf_object_get_information(enum etf_object_class_type type);
etf_err_t etf_object_change_to_run_list(etf_object_t object);
etf_err_t etf_object_change_to_suspend_list(etf_object_t object);


#ifdef __cplusplus
}
#endif
 
#endif
 

