#ifndef	__ETF_I2C_H__
#define	__ETF_I2C_H__

#include "type.h"

#if USE_ETF_I2C

#define	ETF_I2C_WR							0x0000
#define	ETF_I2C_RD							(1u << 0)

struct etf_i2c_msg
{
    etf_uint16_t			addr;
    etf_uint16_t			flags;
    etf_uint16_t			len;
    etf_uint8_t				*buf;
};

#endif

#endif