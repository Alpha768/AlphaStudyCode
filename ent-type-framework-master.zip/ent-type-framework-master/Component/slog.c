/**
 * Copyright (c) 2006-2020, zwl
 * 
 * description  简单的log信息打印管理
 * 
 * Change Logs:
 * Date             Author         Notes
 * 2019-03-19       zwl             [0.0.1]创建
 * 
 */
#include "string.h"
#include "EntTypeFramework.h"
#include "Bsp.h"
#include "console.h"
#include "slog.h"

#if  USE_SLOG

slog_ctrl *                     SlogListHead                = NULL;
slog_ctrl *                     SlogListLast                = NULL;
slog_ctrl *                     SlogListIndex               = NULL;

/**
 *  设置slog结构体
 *
 *@param :  pslog   ：需要设置的结构；
 *          tag     ：标签名；
 *          valid   ：有效值
 *
 *@return:
 *
 *@note  : 
 *
 *
 */
void slog_config(slog_ctrl *pslog, char *tag, etf_uint8_t valid){
    /* tag赋值 */
    pslog->Tag[CONFIG_SLOG_TAG_SIZE]                        = '\0';
    etf_strncpy(pslog->Tag, tag, CONFIG_SLOG_TAG_SIZE);
    /* 初始是否有效 */
    pslog->Valid                                            = valid;
    pslog->ANoValid                                         = 0;    //1:全关；0：根据Valid值来
    /* 配置链表 */
    pslog->Next                                             = NULL;

    if(NULL == SlogListHead){
        SlogListHead                                        = pslog;
        SlogListLast                                        = pslog;
        SlogListIndex                                       = pslog;
    } else {
        SlogListLast->Next                                  = pslog;
        SlogListLast                                        = pslog;
    }
}

/* slog链表 */
extern void(*SlogInitList[])(void);

/**
 *  执行SlogInitList列表的函数数组
 *
 *@param :
 *
 *@return:
 *
 *@note  : 
 *
 *
 */
void SlogInit(void){
    etf_uint8_t                 i;
	
    for(i = 0; SlogInitList[i] != NULL; i++){
        SlogInitList[i]();
    }
}

#if  USE_CONSOLE_UART

/**
 *  控制台命令 slog_list 处理函数，打印slog列表
 *
 *@param :  argc：参数数目；
 *          argv：指令参数结构
 *
 *@return:  结果
 *
 *@note  : 
 *
 *
 */
int ConCmd_slog_List(etf_int32_t argc, con_cmd_analysis *argv){
    char                        ValidStr[5];
    
    SlogListIndex                                           = SlogListHead;

    printf("---------------------------------------------\r\n");
    printf("    [TAG]        | [VALID]\r\n");
    printf("---------------------------------------------\r\n");
  
    if(NULL != SlogListIndex){
        if(1 == SlogListIndex->ANoValid){
            /* 全关状态提示 */
            printf("         all off          \r\n");
        }
    }
    while(NULL != SlogListIndex){
        /* 解析slog标签有效等级 */
        ValidStr[0]                                         = '\0';
        if(SLOG_F_VALID == SlogListIndex->Valid){
            etf_strncpy(ValidStr, "-", 5);
        } else if(SLOG_T_VALID == SlogListIndex->Valid){
            etf_strncpy(ValidStr, "E-I-D", 5);
        } else {
            if(SLOG_E_VALID == (SLOG_E_VALID&SlogListIndex->Valid)){
                if(0 == etf_strlen(ValidStr)){
                    strcat(ValidStr, "E");
                } else {
                    strcat(ValidStr, "-E");
                }
            }

            if(SLOG_I_VALID == (SLOG_I_VALID&SlogListIndex->Valid)){
                if(0 == etf_strlen(ValidStr)){
                    strcat(ValidStr, "I");
                } else {
                    strcat(ValidStr, "-I");
                }
            }

            if(SLOG_D_VALID == (SLOG_D_VALID&SlogListIndex->Valid)){
                if(0 == etf_strlen(ValidStr)){
                    strcat(ValidStr, "D");
                } else {
                    strcat(ValidStr, "-D");
                }
            }
        }
        printf("%10s       | %s\r\n", SlogListIndex->Tag, ValidStr);
        SlogListIndex                                       = SlogListIndex->Next;
    }
    printf("---------------------------------------------\r\n");
    return 0;
}

/**
 *  控制台命令 slog_filter 处理函数，通过标签对slog打印输出动态滤波管理
 *
 *@param :  argc：参数数目；
 *          argv：指令参数结构
 *
 *@return:
 *
 *@note  : 
 *
 *
 */
int ConCmd_slog_Filter(int argc, con_cmd_analysis *argv){

    if(3 == argc){
        SlogListIndex                                       = SlogListHead;
        while(NULL != SlogListIndex){
        
            if(!etf_strncmp("tag", argv->CmdIn[1], CONFIG_CONSOLE_CMD_SIZE)){
                /* 内部指令,控制所有slog信息状态 */
                if(!etf_strncmp("f", argv->CmdIn[2], CONFIG_CONSOLE_CMD_SIZE)){
                    /* 全关SLOG信息 */
                    SlogListIndex->ANoValid                 = 1;
                } else if(!etf_strncmp("r", argv->CmdIn[2], CONFIG_CONSOLE_CMD_SIZE)){
                    /* 恢复原始状态 */
                    SlogListIndex->ANoValid                 = 0;
                }
            } else if(!etf_strncmp(SlogListIndex->Tag, argv->CmdIn[1], CONFIG_CONSOLE_CMD_SIZE)){
                /* 匹配到标签 */
                if(!etf_strncmp("t", argv->CmdIn[2], CONFIG_CONSOLE_CMD_SIZE)){
                    SlogListIndex->Valid                    = SLOG_T_VALID;
                } else if(!etf_strncmp("f", argv->CmdIn[2], CONFIG_CONSOLE_CMD_SIZE)){
                    SlogListIndex->Valid                    = SLOG_F_VALID;
                } else if(!etf_strncmp("e", argv->CmdIn[2], CONFIG_CONSOLE_CMD_SIZE)){
                    if(SLOG_E_VALID == (SLOG_E_VALID & SlogListIndex->Valid)){
                        SlogListIndex->Valid                = (SlogListIndex->Valid&(~SLOG_E_VALID));
                    } else {
                        SlogListIndex->Valid                = (SlogListIndex->Valid|SLOG_E_VALID);
                    }
                } else if(!etf_strncmp("i", argv->CmdIn[2], CONFIG_CONSOLE_CMD_SIZE)){
                    if(SLOG_I_VALID == (SLOG_I_VALID & SlogListIndex->Valid)){
                        SlogListIndex->Valid                = (SlogListIndex->Valid&(~SLOG_I_VALID));
                    } else {
                        SlogListIndex->Valid                = (SlogListIndex->Valid|SLOG_I_VALID);
                    }
                } else if(!etf_strncmp("d", argv->CmdIn[2], CONFIG_CONSOLE_CMD_SIZE)){
                    if(SLOG_D_VALID == (SLOG_D_VALID & SlogListIndex->Valid)){
                        SlogListIndex->Valid                = (SlogListIndex->Valid&(~SLOG_D_VALID));
                    } else {
                        SlogListIndex->Valid                = (SlogListIndex->Valid|SLOG_D_VALID);
                    }
                } else {
                    printf("parameter err:slog_filter tag e|i|d|t|f\r\n");
                } 
            }
            SlogListIndex                                   = SlogListIndex->Next;
        }
    } else {
        printf("input is invalid:slog_filter tag e|i|d|t|f\r\n");
    }
    return 0;
}

/* 定义slog标签 */
slog_ctrl                       SlogTest;
void slog_test(void){
  slog_config(&SlogTest, "slog_tst", SLOG_T_VALID);
}

/* ************************************************************* **
 * 函数名称：int ConCmd_slog_Test(int argc, CON_CMD_ANALYSIS_T *argv)
 * 函数功能：控制台命令 slog_test 处理函数, 测试slog输出
 * 入口参数：argc：参数数目；argv：指令参数结构
 * 出口参数：0：执行成功
** ************************************************************* */
int ConCmd_slog_Test(int argc, con_cmd_analysis *argv){
  SLOG_E(SlogTest, "%s", "test sloh error.");
  SLOG_I(SlogTest, "%s", "test sloh info.");
  SLOG_D(SlogTest, "%s", "test sloh debug.");
  return 0;
}

/* 控制台指令结构 */
/* slog列表 */
con_cmd         ConCmdSlogList      = {
    .Cmd                            = "slog_list",
    .DesStr                         = "Print slog list.\r\n",
    .Fun                            = ConCmd_slog_List
};

/* slog滤波 */
con_cmd         ConCmdSlogFilter    = {
  .Cmd                              = "slog_filter",
  .DesStr                           = "Print slog filter.\r\n",
  .Fun                              = ConCmd_slog_Filter
};

/* slog输出测试 */
con_cmd         ConCmdSlogTest      = {
  .Cmd                              = "slog_test",
  .DesStr                           = "Print slog test.\r\n",
  .Fun                              = ConCmd_slog_Test
};

#endif

#endif



