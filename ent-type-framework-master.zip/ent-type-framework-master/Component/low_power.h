#ifndef	__LOW_POWER_H__
#define	__LOW_POWER_H__

#include "type.h"
#include "Timer.h"
#if USE_LP

#define	LP_IDLE_LP_TIMER                                                    etf_from_ms_to_tick(30*1000)//(30*1000)/(1000/ETF_TIMER_CLOCK_SEC))	//30s max 设置最大休眠时间，即使当前到下一个事件的空闲时间大于这个时间，
																													//也是按照这个时间来休眠，时间到唤醒设备，重新计算休眠时间，继续休眠，
																													//比如当前到下一个事件的事件是2min，设备会30s唤醒一次，直到事件到达。
																													//最大值受限于硬件定时器定时时间，还需要综合考虑看门狗。
																																							
#define	LP_IDLE_LP_TIMER_LIMIT												etf_from_ms_to_tick(200)//(200/(1000/ETF_TIMER_CLOCK_SEC))		//当空闲时间小于这个值的时候不进行休眠，这个数值不应太小


#define LP_EXIT_SLEEP()                                                     do{SCB->SCR &= (~(1u<<1));}while(0)		//设置中断唤醒后退出中断，不自动进入休眠

//休眠锁状态标志
typedef enum {
	LP_SLEEP_LOCK_STA,
	LP_SLEEP_UNLOCK_STA
}LP_SLEEP_LOCK_STA_E;

//低功耗模式
typedef enum {
	LP_SLEEP_MODE_FALSE,
	LP_SLEEP_MODE_TRUE
}LP_SLEEP_MODE_E;

void LP_CompensateClock(void);
void LP_process_run(void);
void LP_SleepLock(void);
void LP_SleepUnLock(void);
void LP_EnterSleep(void);
void LP_SleepExit(void);
LP_SLEEP_MODE_E LP_SleepModeGet(void);
LP_SLEEP_LOCK_STA_E LP_SleepLockStaGet(void);
#endif

#endif