/**
 * Copyright (c) 2006-2020, zwl
 * 
 * description  i2c通讯封装组件
 * 
 * Change Logs:
 * Date             Author         Notes
 * 2021-10-25       zwl             [0.0.1]创建
 * 
 */
#include "EntTypeFramework.h"
#include "Bsp.h"
#include "etf_i2c.h"

#if USE_ETF_I2C

typedef enum{
	ETF_I2C_IDEL, 
	ETF_I2C_START, 
	ETF_I2C_RESTART, 
	ETF_I2C_STOP,
	ETF_I2C_R_ACK,
	ETF_I2C_R_NACK,
	ETF_I2C_T_ACK,
	ETF_I2C_T_NACK
} ETF_I2C_STA_E;

typedef struct{
	ETF_I2C_STA_E					sta;
	etf_uint8_t						tx_len_count;
	etf_uint8_t						rx_len_count;
	struct etf_i2c_msg				*data;
	etf_uint8_t						num;
	etf_uint8_t						num_count;
}ETF_I2C_CTRL_T;

#endif