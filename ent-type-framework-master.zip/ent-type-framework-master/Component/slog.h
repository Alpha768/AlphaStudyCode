#ifndef	__SLOG_H
#define	__SLOG_H

#include <stdio.h>
#include "console.h"

#if USE_SLOG

typedef struct slog_ctrl{
  char                      Tag[CONFIG_SLOG_TAG_SIZE+1];
  etf_uint8_t               Valid;
  etf_uint8_t               ANoValid;
  struct slog_ctrl  *       Next;
}slog_ctrl;

/* 自动接口初始化列表 */
#define	SLOG_AUTO_INIT(...)						void(*SlogInitList[])(void)={__VA_ARGS__, NULL}

#define SLOG_E_VALID                  0x01                                          //只打印错误信息Error
#define SLOG_I_VALID                  0x02                                          //只打印提示信息Info
#define SLOG_D_VALID                  0x04                                          //只打印调试信息Debug
#define SLOG_T_VALID                  (SLOG_E_VALID|SLOG_I_VALID|SLOG_D_VALID)      //全部打印
#define SLOG_F_VALID                  0x00                                          //关闭打印


#if USE_SLOG_COLOR
#define SLOG_E(slog, fmt, args...)      do{                                                                                 \
                                            if((SLOG_E_VALID == (SLOG_E_VALID&slog.Valid)) && (0 == slog.ANoValid)){        \
                                                printf("\033[40;31m");                                                      \
                                                printf("slog [E/%s] %s:%d : "fmt, slog.Tag, __FUNCTION__, __LINE__, args);  \
                                                printf("\033[0m\r\n");                                                      \
                                            }                                                                               \
                                        }while(0)

#define SLOG_I(slog, fmt, args...)      do{                                                                                 \
                                            if((SLOG_I_VALID == (SLOG_I_VALID&slog.Valid)) && (0 == slog.ANoValid)){        \
                                                printf("\033[40;32m");                                                      \
                                                printf("slog [I/%s] %s:%d : "fmt, slog.Tag, __FUNCTION__, __LINE__, args);  \
                                                printf("\033[0m\r\n");                                                      \
                                            }                                                                               \
                                        }while(0)
#else
#define SLOG_E(slog, fmt, args...)      do{                                                                                 \
                                            if((SLOG_E_VALID == (SLOG_E_VALID&slog.Valid)) && (0 == slog.ANoValid)){        \
                                                printf("slog [E/%s] %s:%d : "fmt, slog.Tag, __FUNCTION__, __LINE__, args);  \
                                                printf("\r\n");                                                             \
                                            }                                                                               \
                                        }while(0)

#define SLOG_I(slog, fmt, args...)      do{                                                                                 \
                                            if((SLOG_I_VALID == (SLOG_I_VALID&slog.Valid)) && (0 == slog.ANoValid)){        \
                                                printf("slog [I/%s] %s:%d : "fmt, slog.Tag, __FUNCTION__, __LINE__, args);  \
                                                printf("\r\n");                                                             \
                                            }                                                                               \
                                        }while(0)

#endif

#define SLOG_D(slog, fmt, args...)      do{                                                                                 \
                                            if((SLOG_D_VALID == (SLOG_D_VALID&slog.Valid)) && (0 == slog.ANoValid)){        \
                                                printf("slog [D/%s] %s:%d : "fmt, slog.Tag, __FUNCTION__, __LINE__, args);  \
                                                printf("\r\n");                                                             \
                                            }                                                                               \
                                        }while(0)


extern slog_ctrl *                      SlogListHead;
extern slog_ctrl *                      SlogListLast;
extern slog_ctrl *                      SlogListIndex;

#ifdef  USE_CONSOLE_UART

extern con_cmd                          ConCmdSlogList;
extern con_cmd                          ConCmdSlogFilter;
extern con_cmd                          ConCmdSlogTest;

void slog_config(slog_ctrl *pslog, char *tag, etf_uint8_t valid);
void SlogInit(void);
void slog_test(void);
#endif

#endif

#endif


