#ifndef	__CONSOLE_H__
#define	__CONSOLE_H__

#include "type.h"

#if USE_CONSOLE_UART
/* 自动接口初始化列表 */
#define	CON_CMD_TABLE(...)                      const con_cmd * const ConCmdTable[]={__VA_ARGS__, NULL};

#define CMD_IN_ARR_SIZE                         (CONFIG_CONSOLE_CMD_PARA_SIZE*CONFIG_CONSOLE_CMD_SIZE + CONFIG_CONSOLE_CMD_PARA_SIZE)
/*             指令无错误              指令参数错误            识别到内部指令*/
typedef enum {CON_CMD_NO_ERR = 0, CON_CMD_PARA_ERR, CON_CMD_TAB, CON_CMD_UP, CON_CMD_DOWN} com_cmd_sta_e;

/* 接收输入指令的结构 */
typedef struct{
                /* 存放终端输入的数据，总长度=(指令+参数)数量*单独指令长度 + 指令个数(空格个数) */
  char          CmdIn[CMD_IN_ARR_SIZE];
  etf_uint16_t  Index;                        /* 可以移动更改输入的索引 */
  etf_uint16_t  LastIndex;                    /* 当前输入的总长度 */
  com_cmd_sta_e Sta;                          /* 指令状态值 */
  etf_uint8_t   Lock;                         /* 指令锁，当前指令正在分析，执行，上锁 */
  etf_uint8_t   CombinationCount;             /* 识别符合指令计数用，例如：上，下，左，右等 */
}con_cmd_in;

typedef struct{
  char                              CmdIn[CONFIG_CONSOLE_CMD_PARA_SIZE+1][CONFIG_CONSOLE_CMD_SIZE+1];
  etf_uint8_t                       argc;
}con_cmd_analysis;


/* 自定义添加的指令结构 */
typedef struct{
  /* 指令 */
  char      Cmd[CONFIG_CONSOLE_CMD_SIZE];
  /* 描述 */
  char      *DesStr;
  /* 指令执行函数 */
  etf_int32_t (*Fun)(etf_int32_t argc, con_cmd_analysis *argv);
}con_cmd;

etf_err_t console_ps_init(void);

extern const con_cmd                      ConCmdReboot;
extern const con_cmd                      ConCmdVersion;
extern const con_cmd                      ConCmdHelp;
extern const con_cmd                      ConCmdDevice;
extern const con_cmd                      ConCmdEvent;
extern const con_cmd                      ConCmdTimer;
extern const con_cmd                      ConCmdCoroutine;
#endif
#endif

