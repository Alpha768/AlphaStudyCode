#ifndef EOS_LED_H__
#define EOS_LED_H__

void eos_led_init(void);

#endif
