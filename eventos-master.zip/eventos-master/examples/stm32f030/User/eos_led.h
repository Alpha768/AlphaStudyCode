#ifndef EOS_LED_H__
#define EOS_LED_H__

void eos_reactor_led_init(void);
void eos_sm_led_init(void);

#endif
