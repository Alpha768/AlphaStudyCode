
#ifndef EVENT_DEF_H__
#define EVENT_DEF_H__

#include "eventos.h"

enum {
    Event_Test = Event_User,
    Event_Time_500ms,
    Event_Time_1000ms,

    Event_ActEnd,
    
    Event_Max
};

#endif
