#include "template.h"

eos_s32_t eos_module_init(void)
{
    return 0;
}

void eos_module_poll(eos_time_t time)
{
    if (time.)
}

void eos_module_end(void)
{

}
