
#ifndef EVENT_DEF_H__
#define EVENT_DEF_H__

#include "eventos.h"

enum {
    Event_Test = Event_User,
    Event_Time_500ms,

    Event_Max
};

#endif
