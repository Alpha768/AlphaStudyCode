# EventOS Nano产品说明
-----------
本项目已经关闭，此项目已经合并至：[EventOS](https://gitee.com/event-os/eventos)